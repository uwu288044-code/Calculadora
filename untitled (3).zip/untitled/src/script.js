// Crear un <style> y agregarlo al <head>
const style = document.createElement('style');
style.innerHTML = `
  .full-viewport-height {
    height: 100vh;
  }

  @supports (height: 100dvh) {
    .full-viewport-height {
      height: 100dvh;
    }
  }

  .remove {
    position: absolute;
    bottom: 5px;
    right: 5px;
    cursor: pointer;
    color: red;
    border-radius: 50%;
    background-color: white;
    border: 1px solid red;
    width: 30px;
    height: 30px;
    padding: 2px;
    text-align: center;
    font-weight: bold;
  }

  .container-footer {
    width: 100%;
    background-color: #cbd2d1;
    padding: 10px;
    text-align: center;
  }

  .footer-text {
    padding: 0px;
    margin: 0px;
  }

  .footer-subtext {
    padding: 0px;
    margin: 0px;
    font-size: 0.9rem;
  }

  .titulo-principal {
    font-size: 2rem;
    font-weight: bolder;
  }

  .alert-personalizado {
    margin: 10px 0;
    position: relative;
